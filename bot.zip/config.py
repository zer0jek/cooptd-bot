# Konfiguracja progów punktowych i ID ról Discorda
# Uzupełnij ID ról zgodnie z Twoim serwerem Discord
ROLE_THRESHOLDS = [
    (1000, 1418695474940219492),  # np. 1000+
    (500, 1418695450709594382),  # np. 500+
    (100,  1418695425401294909),  # np. 100+
]
